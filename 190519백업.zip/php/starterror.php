<html>

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>

<body>

<?

echo '로그인 실패입니다'; //로그인실패
echo '<a href="./index.php">로그인화면으로가기</a>';   
?> 

</body>

</html>
