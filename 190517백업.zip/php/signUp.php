

<?php
error_reporting(E_ALL);

ini_set("display_errors", 1);
session_start();
header("Content-Type:application/json");
$host = 'localhost';
$user = 'torest';
$pw = 'team14torest';
$dbName = 'torest';

$mysqli = new mysqli($host, $user, $pw, $dbName);
$_POST = JSON_DECODE(file_get_contents("php://input"), true); //mysql로 접근 하도록 설정



    $memberId = $_POST["id"];
    $memberPw = $_POST["pw"];
	$_SESSION["signup"] = $memberId;
    echo $_POST["id"];
    echo $_POST["pw"];

 $sql = "insert into user (id,pw)";             // (입력받음)insert into 테이블명 (column-list)
 $sql = $sql. "values('$memberId','$memberPw')";         // calues(column-list에 넣을 value-list)
 if($mysqli->query($sql)){                                                              //만약 sql로 잘 들어갔으면
  echo $_SESSION["signup"].'님 가입 되셨습니다.<p/>';                                   // id님 안녕하세요.
 }else{                                                                                //아니면
  echo 'fail to insert sql';                                                            //fail to insert sql로 표시
 }
mysqli_close($mysqli);
 
 
?>


